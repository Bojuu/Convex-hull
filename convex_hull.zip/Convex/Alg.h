#ifndef ALG_H
#define ALG_H

#include "Point.h"

class Alg {
	Point* data;
	int size;
	int count;
	Point* hull;
	int hull_size;

public:
	Alg(int size);
	~Alg();
	void put(Point& P);
	void remove(int index);
	void base_choose();
	void order_angle();
	void make_hull();
	void write();
};

#endif