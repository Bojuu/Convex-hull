#include <stdio.h>
#include <iostream>

#include "Alg.h"
#include "Point.h"

int main() {			// ~ Graham scan algorithm

	Alg alg(100);		// initial size

	double x;
	double y;
	std::cout << "Type the coordinates of the points. " << std::endl;
	std::cout << "Format: <x><space><y><enter> " << std::endl;
	std::cout << "Ready: EOF (ctrl+Z) " << std::endl;

	std::cin >> x >> y;
	while (!std::cin.eof()) {
		Point P(x, y);
		alg.put(P);
		std::cin >> x >> y;
	}

	alg.base_choose();		// choosing the base point
	alg.order_angle();		// order of the points
	alg.make_hull();		// select the hull-members
	alg.write();			// show the result

	getchar();
	return 0;
}