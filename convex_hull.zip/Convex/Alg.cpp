﻿#include <stdio.h>
#include <iostream>

#include "Alg.h"
#include "Point.h"

Alg::Alg(int s) {			// constructor
	data = NULL;
	hull = NULL;
	count = 0;
	size = s;
	hull_size = 0;
	if (size != 0) {
		data = new Point[size];
	}
}

Alg::~Alg() {				// destructor
	if (count > 0) {
		delete[] data;
	}
	if (hull_size > 0) {
		delete[] hull;
	}
}

void Alg::put(Point& P) {	// putting a point
	if (count >= size) {	// above the default size (allocate new memory)
		Point* temp = new Point[count + 1];
		for (int i = 0; i < count; i++) {
			temp[i] = data[i];
		}
		temp[count] = P;
		++count;
		delete[] data;
		data = temp;
	}
	else {
		data[count] = P;
		++count;
	}
}

void Alg::remove(int index) {		// remove a point from the hull
	if (index >= count) {
		std::cerr << "Invalid get index.";
		return;
	}
	count--;
	Point* temp = new Point[count];
	for (int i = 0; i < index; i++) {		// copy to the removing point
		temp[i] = hull[i];
	}
	for (int i = index; i < count; i++) {	// copy from the removing point
		temp[i] = hull[i + 1];
	}
	delete[] hull;
	hull = temp;
}

void Alg::base_choose() {	// choosing the base point (the one with the lowest y coord)

	double min_y = data[0].get_y();
	int index = 0;

	for (int i = 1; i < count; i++) {
		double temp_y = data[i].get_y();
		if (temp_y < min_y) {
			min_y = temp_y;
			index = i;
		}
		else if (temp_y == min_y) {		// equal y -> lower x
			if (data[i].get_x() < data[index].get_x()) {
				index = i;
			}
		}
	}

	if (index != 0) {	// the base will be the first (swap)
		Point temp_point = data[0];
		data[0] = data[index];
		data[index] = temp_point;
	}
}

void Alg::order_angle() {	// order from the biggest cosinus to the smallest (in the point of view the base point)

	for (int i = 1; i < count - 1; i++) {
		for (int j = i + 1; j < count; j++) {
			if (data[0].angle_cos(data[i]) < data[0].angle_cos(data[j]) ||		// if the cosinus is lower, swap
				(data[0].angle_cos(data[i]) == data[0].angle_cos(data[j]) &&	// if the cosinus is equal, the point with a lower distance will be the previous
					data[0].length(data[i]) > data[0].length(data[j]))) {

				Point temp_point = data[i];		// swap
				data[i] = data[j];
				data[j] = temp_point;
			}
		}
	}
}

void Alg::make_hull() {					// select the hull-members

	hull = new Point[count];
	for (int i = 0; i < count; i++) {
		hull[i] = data[i];				// at first every point is in the hull
	}
	hull_size = count;

	if (count <= 2) {					// if there are less than 3 points
		return;
	}

	int i = 0;
	bool end = false;

	while (!end) {		// i -> i+1 -> i+2 examinations (left or right)

		double dir = hull[i].left_right(hull[i + 1], hull[i + 2]);

		if (dir == 1 || dir == 0) {		// if it's a left turn (or straight), the points remain
			i++;
			if (i + 2 == count) {		// if that's the last point: true end
				end = true;
			}
		}
		else if (dir == -1) {			// if it's a right turn...
			remove(i + 1);				// the middle point is surely not hull-member
			hull_size--;
			i--;						// examination with one step back
		}
	}
}

void Alg::write() {
	std::cout << "Points of the convex hull (in order): " << std::endl;
	for (int i = 0; i < hull_size; i++) {
		hull[i].write();
	}
}